package com.marketsimplified;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.marketsimplified.EmployeeDatabase;


@WebServlet("/ServletList")
public class ServletList extends HttpServlet 

{

	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("application/json");

		StringBuffer jb = new StringBuffer();

		String line = null;

		BufferedReader reader = request.getReader();

		while ((line = reader.readLine()) != null) {
		    jb.append(line);
		}

		JSONObject jsobj = new JSONObject(jb.toString());		
		int emptype = jsobj.getInt("emptype");
	
			try 
			{
				
				EmployeeDatabase emp = new EmployeeDatabase();
				String jsonData = emp.list(emptype);				
				response.setContentType("application/json");
		        response.setCharacterEncoding("UTF-8");
		        PrintWriter out = response.getWriter();
		        out.write(jsonData);
		        
			} 
			catch (Exception e) 
			{				
				System.out.println(e);
			}
	}
}
